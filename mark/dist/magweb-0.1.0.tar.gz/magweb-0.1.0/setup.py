from distutils.core import setup


setup(
    name = 'magweb',
    version='0.1.0',
    description='Python WSGI Framework',
    author='thinking',
    author_email='thinking@magedu.com',
    url='https://www.magedu.com',
    packages=['magweb']

)
